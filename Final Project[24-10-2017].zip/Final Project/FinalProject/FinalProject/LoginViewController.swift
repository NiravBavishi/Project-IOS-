//
//  ViewController.swift
//  FinalProject
//
//  Created by MacStudent on 2017-10-23.
//  Copyright © 2017 MacStudent. All rights reserved.
//

import UIKit

class LoginViewController: UIViewController {
    
    
    @IBOutlet weak var txtFieldUserName: UITextField!
    @IBOutlet weak var txtFieldPassword: UITextField!
    
    
    @IBOutlet weak var btnLogin: UIButton!
    @IBOutlet weak var btnSignIn: UIButton!
    
    
    

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
        btnLogin.layer.cornerRadius = 7
        btnSignIn.layer.cornerRadius = 7
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    @IBAction func btnLoginTapped(_ sender: UIButton) {
        
        let UserName = "Admin"
        let UserPassword = "Admin@123"

        if txtFieldUserName.text == UserName && txtFieldPassword.text == UserPassword {
            
            performSegue(withIdentifier: "LoginToHomeSegue", sender: self)
            
        }
        else{
            
            showAlert(Title: "Message", Message: "Invalid Username Or Password")
            
        }
        
    }
    
    
    func showAlert(Title : String, Message: String){
        
        let alert = UIAlertController(title: Title, message: Message, preferredStyle: .alert)
        
        let action1 = UIAlertAction(title: "Ok", style: .default, handler: nil)
        
        alert.addAction(action1)
        
        present(alert, animated: true, completion: nil)
        
    }
    
   
}

