//
//  QuizPageViewController.swift
//  FinalProject
//
//  Created by MacStudent on 2017-10-24.
//  Copyright © 2017 MacStudent. All rights reserved.
//

import UIKit

 var OptionArray = [String]()

class QuizPageViewController: UIViewController, UIPickerViewDelegate, UIPickerViewDataSource {
    
    var QuestionIndex = 0
    var UserAnswer = ""
   
    var Options = [String] ()
    
    @IBOutlet weak var Optionselector: UIPickerView!
    @IBOutlet weak var btnNext: UIButton!
    @IBOutlet weak var lblQuestion: UILabel!
    @IBOutlet weak var QuestionProgress: UIProgressView!
    
    var QuestionData = [Questions]()
   

    override func viewDidLoad() {
        super.viewDidLoad()

        // For Count Quize Started
        
        let CounterQuizstarted = UserDefaults.standard
        
        var counterQuiz = CounterQuizstarted.value(forKey: "CounerQuizStart") as! Int
        
        if (counterQuiz == 0) {
            CounterQuizstarted.set(1, forKey: "CounerQuizStart")
        }else {
            counterQuiz += 1
            
            CounterQuizstarted.set(counterQuiz, forKey: "CounerQuizStart")

        }
        
        
        //// For Count Quize Started
        
        
        QuestionData = Questions.setQuestions()
        
        btnNext.layer.cornerRadius = 7
        
        Optionselector.dataSource = self
        Optionselector.delegate = self
      
        let progValue = Float(QuestionIndex+1) / 10
        QuestionProgress.setProgress(progValue, animated: true)
        

        print("Ok-------------------------")
        print(QuestionData[QuestionIndex].Question!)
        
        OptionArray.append(QuestionData[QuestionIndex].Option1)
        OptionArray.append(QuestionData[QuestionIndex].Option2)
        OptionArray.append(QuestionData[QuestionIndex].Option3)
        OptionArray.append(QuestionData[QuestionIndex].Option4)
        
        
        
        lblQuestion.text = QuestionData[QuestionIndex].Question
        
        QuestionIndex += 1
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */
    
    
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }
    
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        return OptionArray.count
    }
    
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        return OptionArray[row]
    }
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        print(OptionArray[Optionselector.selectedRow(inComponent: 0)])
        
        UserAnswer = OptionArray[Optionselector.selectedRow(inComponent: 0)]
        
        if QuestionIndex == 10 {
            
            btnNext.setTitle("End Quiz", for: .normal)
            
        }else
        {
        
            btnNext.setTitle("Next", for: .normal)
        
        }
    }
    
    
    
    @IBAction func btnNextTapped(_ sender: UIButton) {
        
        if QuestionIndex < 10 {
            
            NextQuestion()
            
        }
            
        else {
            
            print("Ok Above 10 Index")
            
            performSegue(withIdentifier: "QuizToScoreSegue", sender: self)
            
        }
        
      
        
    }
    
    func NextQuestion () {
        
        
        
        
        Questions.AddAnswers(questionNo: QuestionIndex-1, answer: UserAnswer)
        
        
        btnNext.setTitle("Skip", for: .normal)
        Optionselector.selectRow(0, inComponent: 0, animated: true)
        
        
        
        let progValue = Float(QuestionIndex+1) / 10
        
        QuestionProgress.setProgress(progValue, animated: true)
        
        
        OptionArray.removeAll()
        
        
            
        
        
            
//            let QuestionText = QuestionData[QuestionIndex].Question
          //  let AnswerText = QuestionData[QuestionIndex].Answer
        
        print("Answer : \(QuestionData[QuestionIndex].Answer)")
            
            OptionArray.append(QuestionData[QuestionIndex].Option1)
            OptionArray.append(QuestionData[QuestionIndex].Option2)
            OptionArray.append(QuestionData[QuestionIndex].Option3)
            OptionArray.append(QuestionData[QuestionIndex].Option4)
            
            lblQuestion.text = QuestionData[QuestionIndex].Question
            self.Optionselector.reloadAllComponents()
            
       
        QuestionIndex += 1
        if QuestionIndex == 10 {
            
            btnNext.setTitle("End Quiz", for: .normal)
            
        }
        
        
 //End of func NextQuestion()
    }
    
   
    

    
//End Of Class Questions()
}
