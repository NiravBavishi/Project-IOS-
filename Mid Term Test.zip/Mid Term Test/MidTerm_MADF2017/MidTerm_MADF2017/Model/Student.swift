//
//  Student.swift
//  MidTerm_MADF2017
//
//  Created by moxDroid on 2017-10-20.
//  Copyright © 2017 moxDroid. All rights reserved.
//  Student ID : C0717705
//  Student Name : Nirav Bavishi

import Foundation

class Student {
    
    var studentId : String!
    var studentName : String!
    var studentEmail : String!
    var studentDateofBirth : Date!
    var marksIOS : Int = 0
    var marksAndroid : Int = 0
    var marksNet : Int = 0
    var marksJAVA : Int = 0
    var marksHTML : Int = 0
    var studentGrade : String = ""
    var studentPercentage : Float = 0.00
    var studentTotalmarks : Int = 0
    
    
    static var studentData = [String : Student]()
    
    init(){
        
        self.studentId = ""
        self.studentName = ""
        self.studentEmail = ""
        self.studentDateofBirth = nil
        self.marksIOS = 0
        self.marksAndroid = 0
        self.marksNet = 0
        self.marksJAVA = 0
        self.marksHTML = 0
        
        
    }
    
    init(studentId : String, studentName : String, studentEmail : String, studentDateofBirth : Date, marksIOS : Int, marksAndroid : Int, marksNet : Int, marksJAVA : Int, marksHTML : Int){
        
        self.studentId = studentId
        self.studentName = studentName
        self.studentEmail = studentEmail
        self.studentDateofBirth = studentDateofBirth
        self.marksIOS = marksIOS
        self.marksAndroid = marksAndroid
        self.marksNet = marksNet
        self.marksJAVA = marksJAVA
        self.marksHTML = marksHTML
        
        
    }
    
    
    static func addStudent(std : Student) -> Bool {
        
        if (studentData[std.studentId] == nil) {
            
            studentData[std.studentId] = std
            return true
        }else{
        
            return false
        }
    }
    
    static func getStudentData() -> [String : Student] {
        
        return studentData
        
    }
    
    func calculateResult (){
        
        
        let markArray = [marksHTML, marksJAVA, marksNet, marksAndroid, marksIOS]
        var totalMarks = 0
        var result = 0
        
        for i in markArray{
            
            if i > 45 {
                result += 1
            }
            
            totalMarks += i
            
        }
        
        if result > 1 {
            
            
            
            let percentage = Float(totalMarks / 500) * 100
            
            studentPercentage = percentage
            studentTotalmarks = totalMarks
            
            if percentage >= 95{
                
                studentGrade = "A+"
                
            }else if percentage >= 85 && percentage < 95{
                
                studentGrade = "A"
                
            }else if percentage >= 75 && percentage < 85{
                
                studentGrade = "B+"
                
            }else if percentage >= 65 && percentage < 75{
                
                studentGrade = "B"
                
            }else if percentage >= 55 && percentage < 65 {
                
                studentGrade = "C+"
                
            }else if percentage >= 50  && percentage < 55 {
                
                studentGrade = "C"
                
            }else if percentage >= 45  && percentage < 50 {
                
                studentGrade = "D+"
                
            }else if percentage < 45  {
                
                studentGrade = "FAIL"
                
            }
            
        }
        else {
            
            studentPercentage = 0.0
            studentTotalmarks = totalMarks
            
        }
            
    
        
    }
    
}


