//
//  StudentResultViewController.swift
//  MidTerm_MADF2017
//
//  Created by moxDroid on 2017-10-20.
//  Copyright © 2017 moxDroid. All rights reserved.
//  Student ID : C0717705
//  Student Name : Nirav Bavishi

import UIKit

class StudentResultViewController: UIViewController {
    
    
    
    var studentData : Student!
    
    
    
    @IBOutlet weak var txtFieldId: UITextField!
    @IBOutlet weak var txtFieldName: UITextField!
    @IBOutlet weak var txtFieldEmail: UITextField!
    @IBOutlet weak var txtFieldDOB: UITextField!
    @IBOutlet weak var txtFieldIOS: UITextField!
    @IBOutlet weak var txtFieldHTML: UITextField!
    @IBOutlet weak var txtFieldNET: UITextField!
    @IBOutlet weak var txtFieldJAVA: UITextField!
    @IBOutlet weak var txtFieldAndroid: UITextField!
    @IBOutlet weak var txtFieldTotalMarks: UITextField!
    @IBOutlet weak var txtFieldPercentage: UITextField!
    @IBOutlet weak var txtFieldgrade: UITextField!
    
    
    
    

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        
        txtFieldId.text = studentData.studentId
        txtFieldName.text = studentData.studentName
        txtFieldEmail.text = studentData.studentEmail
        
//        let formatter = DateFormatter()
//
////        formatter.dateFormat = "yyyy-MM-dd"
//
////        let myString = formatter.string(from: studentData.studentDateofBirth)
////
//       let yourDate = formatter.date(from: studentData.studentDateofBirth)
//
//        formatter.dateFormat = "dd-MMM-yyyy"
//
//        let DOB = formatter.string(from: yourDate!)
//

        
        let formatter = DateFormatter()
        // initially set the format based on your datepicker date
        formatter.dateFormat = "yyyy-MM-dd HH:mm:ss"
        
        let myString = formatter.string(from: studentData.studentDateofBirth)
        // convert your string to date
        let yourDate = formatter.date(from: myString)
        //then again set the date format whhich type of output you need
        formatter.dateFormat = "dd-MMM-yyyy"
        // again convert your date to string
        let DOB = formatter.string(from: yourDate!)
        
        
        txtFieldDOB.text = DOB
        txtFieldIOS.text = String(studentData.marksIOS)
        txtFieldHTML.text = String(studentData.marksHTML)
        txtFieldNET.text = String(studentData.marksNet)
        txtFieldJAVA.text = String(studentData.marksJAVA)
        txtFieldAndroid.text = String(studentData.marksAndroid)
        txtFieldTotalMarks.text = String(studentData.studentTotalmarks)
        txtFieldPercentage.text = String(studentData.studentPercentage)
        txtFieldgrade.text = studentData.studentGrade
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
