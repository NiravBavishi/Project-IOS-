//
//  QuizPageViewController.swift
//  FinalProject
//
//  Created by MacStudent on 2017-10-24.
//  Copyright © 2017 MacStudent. All rights reserved.
//

import UIKit

class QuizPageViewController: UIViewController, UIPickerViewDelegate, UIPickerViewDataSource {
   
    var Options = [String] ()
    
    @IBOutlet weak var Optionselector: UIPickerView!
    @IBOutlet weak var btnNext: UIButton!
    
    
    

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        
        btnNext.layer.cornerRadius = 7
        
        Optionselector.dataSource = self
        Optionselector.delegate = self
        
        Options = ["Option 1", "Option 2", "Option 3", "Option 4"]
        
        
        var Questionsdictionary = [
            
            1 : [
                
                "Que" : "What is that 1",
                "Op1" : "Option 1",
                "Op2" : "Option 2",
                "Op3" : "Option 3",
                "Op4" : "Option 4",
                "Ans" : "Ans 1"
            ],
            
            2 : [
                
                "Que" : "What is that 2",
                "Op1" : "Option 5",
                "Op2" : "Option 6",
                "Op3" : "Option 7",
                "Op4" : "Option 8",
                "Ans" : "Ans 2"
            ],
            
            3 : [
            
            "Que" : "What is that 3",
            "Op1" : "Option 1",
            "Op2" : "Option 2",
            "Op3" : "Option 3",
            "Op4" : "Option 4",
            "Ans" : "Ans 1"
            ]
            
            
        ]
        
        // access dictionary )))))
        var dictQuestion : [String : String] = Questionsdictionary[1]!
        print(Questionsdictionary.description)
        print(dictQuestion.description)
        print(dictQuestion["Ans"]!)
        
        
        Questions.setQuestions()
//        print(Questions.setQuestions())
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */
    
    
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }
    
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        return Options.count
    }
    
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        return Options[row]
    }
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        print(Options[Optionselector.selectedRow(inComponent: 0)])
    }
    
    
    
    

}
