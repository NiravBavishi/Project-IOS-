//
//  QuizPageViewController.swift
//  FinalProject
//
//  Created by MacStudent on 2017-10-24.
//  Copyright © 2017 MacStudent. All rights reserved.
//

import UIKit

 var OptionArray = [String]()

class QuizPageViewController: UIViewController, UIPickerViewDelegate, UIPickerViewDataSource {
    
    var QuestionIndex = 0
    var UserAnswer = ""
   
    var Options = [String] ()
    
    @IBOutlet weak var Optionselector: UIPickerView!
    @IBOutlet weak var btnNext: UIButton!
    @IBOutlet weak var lblQuestion: UILabel!
    @IBOutlet weak var QuestionProgress: UIProgressView!
    
    

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        
        btnNext.layer.cornerRadius = 7
        
        Optionselector.dataSource = self
        Optionselector.delegate = self
      
        let progValue = Float(QuestionIndex+1) / 10
        QuestionProgress.setProgress(progValue, animated: true)
        
       var dictQuestiontemp = Questions.setQuestions(Indexex: 1)
        
       // dictQuestiontemp["Question"]
        print("Ok-------------------------")
        print(dictQuestiontemp[QuestionIndex].Question!)
        
        OptionArray.append(dictQuestiontemp[QuestionIndex].Option1)
        OptionArray.append(dictQuestiontemp[QuestionIndex].Option2)
        OptionArray.append(dictQuestiontemp[QuestionIndex].Option3)
        OptionArray.append(dictQuestiontemp[QuestionIndex].Option4)
        
        
        
        lblQuestion.text = dictQuestiontemp[QuestionIndex].Question
        
        QuestionIndex += 1
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */
    
    
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }
    
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        return OptionArray.count
    }
    
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        return OptionArray[row]
    }
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        print(OptionArray[Optionselector.selectedRow(inComponent: 0)])
        
        UserAnswer = OptionArray[Optionselector.selectedRow(inComponent: 0)]
        
        btnNext.setTitle("Next", for: .normal)
    }
    
    
    
    @IBAction func btnNextTapped(_ sender: UIButton) {
        
      NextQuestion()
        
    }
    
    func NextQuestion () {
        
        
        
        
        Questions.AddAnswers(questionNo: QuestionIndex, answer: UserAnswer)
        
        
        btnNext.setTitle("Skip", for: .normal)
        Optionselector.selectRow(0, inComponent: 0, animated: true)
        
        if QuestionIndex == 9 {
            
            btnNext.setTitle("End Quiz", for: .normal)
            
        }
        
        let progValue = Float(QuestionIndex+1) / 10
        
        QuestionProgress.setProgress(progValue, animated: true)
        
        
        OptionArray.removeAll()
        
        if QuestionIndex < 10 {
            
            var QuestionData = Questions.setQuestions(Indexex: QuestionIndex)
            QuestionIndex += 1
            
//            let QuestionText = QuestionData[QuestionIndex].Question
            //let AnswerText = QuestionData["Answer"]
            
            OptionArray.append(QuestionData[QuestionIndex].Option1)
            OptionArray.append(QuestionData[QuestionIndex].Option2)
            OptionArray.append(QuestionData[QuestionIndex].Option3)
            OptionArray.append(QuestionData[QuestionIndex].Option4)
            
            lblQuestion.text = QuestionData[QuestionIndex].Question
            self.Optionselector.reloadAllComponents()
            
        }
            
        else {
            
            print("Ok Above 10 Index")
            
        }
        
        
        
        
 //End of func NextQuestion()
    }
    
   
    

    
//End Of Class Questions()
}
