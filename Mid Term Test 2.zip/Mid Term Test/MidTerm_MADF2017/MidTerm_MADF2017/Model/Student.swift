//
//  Student.swift
//  MidTerm_MADF2017
//
//  Created by moxDroid on 2017-10-20.
//  Copyright © 2017 moxDroid. All rights reserved.
//  Student ID : C0717705
//  Student Name : Nirav Bavishi

import Foundation

class Student {
    
    var studentId : String!
    var studentName : String!
    var studentEmail : String!
    var studentDateofBirth : String!
    var marksIOS : Int!
    var marksAndroid : Int!
    var marksNet : Int!
    var marksJAVA : Int!
    var marksHTML : Int!
    
    static var studentData = [String : Student]()
    
    init(){
        
        self.studentId = ""
        self.studentName = ""
        self.studentEmail = ""
        self.studentDateofBirth = ""
        self.marksIOS = 0
        self.marksAndroid = 0
        self.marksNet = 0
        self.marksJAVA = 0
        self.marksHTML = 0
        
    }
    
    init(studentId : String, studentName : String, studentEmail : String, studentDateofBirth : String, marksIOS : Int, marksAndroid : Int, marksNet : Int, marksJAVA : Int, marksHTML : Int){
        
        self.studentId = ""
        self.studentName = ""
        self.studentEmail = ""
        self.studentDateofBirth = ""
        self.marksIOS = 0
        self.marksAndroid = 0
        self.marksNet = 0
        self.marksJAVA = 0
        self.marksHTML = 0
        
    }
    
    
    static func addStudent(std : Student) -> Bool {
        
        if (studentData[std.studentId] == nil) {
            
            studentData[std.studentId] = std
            return true
        }else{
        
            return false
        }
    }
    
    static func getStudentData() -> [String : Student] {
        
        return studentData
        
    }
    
}


