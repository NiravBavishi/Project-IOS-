//
//  ViewController.swift
//  MidTerm_MADF2017
//
//  Created by moxDroid on 2017-10-20.
//  Copyright © 2017 moxDroid. All rights reserved.
//  Student ID : C0717705
//  Student Name : Nirav Bavishi

import UIKit

class LoginViewController : UIViewController {
    
    
    @IBOutlet weak var txtFieldUserName: UITextField!
    @IBOutlet weak var txtFieldPassword: UITextField!
    
    

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    
    
    @IBAction func btnLoginTapped(_ sender: UIButton) {
        
        let UserId = "C0717705"
        let UserPassword = "Nirav"
        
        if txtFieldUserName.text == UserId && txtFieldPassword.text == UserPassword {
            

                    performSegue(withIdentifier: "LoginToEntrySegue", sender: self)
            
        }else{
            
            let alert = UIAlertController(title: "Message", message: "Invalid user id or password", preferredStyle: .alert)
            
            alert.addAction(UIAlertAction(title: "Ok", style: .default, handler: nil))
            
            self.present(alert, animated: true, completion: nil)
            
        }
        
    }

   

}

