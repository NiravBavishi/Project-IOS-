//
//  StudentEntryViewController.swift
//  MidTerm_MADF2017
//
//  Created by moxDroid on 2017-10-20.
//  Copyright © 2017 moxDroid. All rights reserved.
//  Student ID : C0717705
//  Student Name : Nirav Bavishi

import UIKit

class StudentEntryViewController: UIViewController {
    
    
    @IBOutlet weak var txtFieldId: UITextField!
    @IBOutlet weak var txtFieldName: UITextField!
    @IBOutlet weak var txtFieldEmail: UITextField!
    @IBOutlet weak var txtFieldDOB: UITextField!
    @IBOutlet weak var txtFieldIOSMarks: UITextField!
    @IBOutlet weak var txtFieldAndroidMarks: UITextField!
    @IBOutlet weak var txtFieldNetMarks: UITextField!
    @IBOutlet weak var txtFieldJAVAMarks: UITextField!
    @IBOutlet weak var txtFieldHTMLMarks: UITextField!
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
